import React, { useState, useEffect } from "react";
import Web3 from "web3";
import provenanceABI from "../provenance.json";
import entityABI from "../entity.json";
import { useNavigate } from "react-router-dom";

declare global {
  interface Window {
    ethereum?: any;
  }
}

const PROVENANCE_CONTRACT_ADDRESS = "0x8591a80704ef7D7f4DBecf8Fce5700A1909d6eE0";
const ENTITY_CONTRACT_ADDRESS = "0x7680edBD58bC398fae8fd03B6fcab0DfF42d3D6F";

const RegisterComponent: React.FC = () => {
  const [componentId, setComponentId] = useState("");
  const [location, setLocation] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  useEffect(() => {
    const checkRegistration = async () => {
      if (!window.ethereum) {
        setMessage("Please install MetaMask.");
        return;
      }

      const web3 = new Web3(window.ethereum);
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const accounts = await web3.eth.getAccounts();
      const account = accounts[0];

      const entityContract = new web3.eth.Contract(
        entityABI as any,
        ENTITY_CONTRACT_ADDRESS
      );

      try {
        const isRegistered = await entityContract.methods
          .isEntityRegistered(account)
          .call();

        if (!isRegistered) {
          alert("Access denied: You must be a registered entity.");
          navigate("/");
        } else {
          setLoading(false);
        }
      } catch (error) {
        console.error("Error checking registration", error);
        setMessage("Error verifying entity registration.");
      }
    };

    checkRegistration();
  }, [navigate]);

  const handleRegister = async () => {
    if (!window.ethereum) {
      setMessage("Please install MetaMask.");
      return;
    }

    try {
      const web3 = new Web3(window.ethereum);
      const accounts = await web3.eth.getAccounts();

      const contract = new web3.eth.Contract(
        provenanceABI as any,
        PROVENANCE_CONTRACT_ADDRESS
      );

      await contract.methods
        .registerComponent(componentId, location)
        .send({ from: accounts[0] });

      setMessage("✅ Component registered successfully!");
    } catch (err: any) {
      console.error(err);
      setMessage(" Error: " + (err?.message || "Something went wrong."));
    }
  };

  if (loading) {
    return <p className="p-8 text-center">Checking access...</p>;
  }

  return (
    <div className="p-8 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Register Component</h1>

      <input
        type="text"
        placeholder="Component ID"
        value={componentId}
        onChange={(e) => setComponentId(e.target.value)}
        className="border px-4 py-2 w-full mb-4"
      />

      <input
        type="text"
        placeholder="Location"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        className="border px-4 py-2 w-full mb-4"
      />

      <button
        onClick={handleRegister}
        className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
      >
        Register
      </button>

      {message && <p className="mt-4">{message}</p>}
    </div>
  );
};

export default RegisterComponent;
