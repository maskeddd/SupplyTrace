import React, { useState } from "react";
import Web3 from "web3";
import provenanceABI from "../provenance.json";

const CONTRACT_ADDRESS = "0x8591a80704ef7D7f4DBecf8Fce5700A1909d6eE0";

const MarkStolenProduct: React.FC = () => {
  const [productId, setProductId] = useState("");
  const [message, setMessage] = useState("");

  const handleMarkStolen = async () => {
    if (!window.ethereum) {
      setMessage(" MetaMask not detected.");
      return;
    }

    try {
      const web3 = new Web3(window.ethereum);
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const accounts = await web3.eth.getAccounts();

      const contract = new web3.eth.Contract(provenanceABI as any, CONTRACT_ADDRESS);

      await contract.methods.markAsStolen(productId).send({ from: accounts[0] });

      setMessage(" Product successfully marked as stolen.");
    } catch (err: any) {
      console.error(err);
      setMessage(" Error: " + (err?.message || "An unexpected error occurred."));
    }
  };

  return (
    <div className="p-8 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Mark Product as Stolen</h2>
      <input
        type="text"
        placeholder="Enter Product ID"
        value={productId}
        onChange={(e) => setProductId(e.target.value)}
        className="border px-4 py-2 w-full mb-4"
      />
      <button
        onClick={handleMarkStolen}
        className="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700"
      >
        Mark as Stolen
      </button>
      {message && <p className="mt-4">{message}</p>}
    </div>
  );
};

export default MarkStolenProduct;
